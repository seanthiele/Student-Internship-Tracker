import { 
  useGetInternshipStats, 
  getGetInternshipStatsQueryKey,
  useGetUpcomingDeadlines,
  getGetUpcomingDeadlinesQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { InternshipStatusBadge } from "@/components/internship-status-badge";
import { format } from "date-fns";
import { Building2, TrendingUp, CheckCircle2, XCircle, AlertCircle, Clock, Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: stats, isLoading: isStatsLoading } = useGetInternshipStats({
    query: {
      queryKey: getGetInternshipStatsQueryKey()
    }
  });

  const { data: deadlines, isLoading: isDeadlinesLoading } = useGetUpcomingDeadlines({ days: 14 }, {
    query: {
      queryKey: getGetUpcomingDeadlinesQueryKey({ days: 14 })
    }
  });

  if (isStatsLoading || isDeadlinesLoading) {
    return (
      <div className="space-y-8 animate-in fade-in">
        <div className="space-y-2">
          <Skeleton className="h-10 w-[200px]" />
          <Skeleton className="h-5 w-[300px]" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
      </div>
    );
  }

  if (!stats) return null;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-1">
        <h1 className="text-3xl font-serif font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground text-lg">Your recruiting pipeline at a glance.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Applications</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeApplications || stats.byStatus.applied + stats.byStatus.interviewing}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Offers</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.byStatus.offered + stats.byStatus.accepted}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rejections</CardTitle>
            <XCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.byStatus.rejected}</div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-primary" />
            Upcoming Deadlines
          </CardTitle>
          <CardDescription>Action items within the next 14 days.</CardDescription>
        </CardHeader>
        <CardContent>
          {!deadlines || deadlines.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground flex flex-col items-center justify-center">
              <CheckCircle2 className="h-8 w-8 mb-2 opacity-20" />
              <p>No immediate deadlines approaching. You are all caught up!</p>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {deadlines.map((item, idx) => {
                const isCritical = item.urgency === "critical";
                const isHigh = item.urgency === "high";
                const isMedium = item.urgency === "medium";
                
                return (
                  <Link key={`${item.internship.id}-${item.deadlineType}-${idx}`} href={`/internships/${item.internship.id}`}>
                    <div className={`p-4 rounded-xl border flex flex-col gap-3 transition-colors hover:bg-muted/50 cursor-pointer ${
                      isCritical ? 'border-destructive/40 bg-destructive/5 dark:bg-destructive/10' :
                      isHigh ? 'border-orange-500/40 bg-orange-500/5 dark:bg-orange-500/10' :
                      isMedium ? 'border-yellow-500/40 bg-yellow-500/5 dark:bg-yellow-500/10' :
                      'border-border bg-card'
                    }`}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1">
                          <h3 className="font-semibold leading-none">{item.internship.company}</h3>
                          <p className="text-sm text-muted-foreground line-clamp-1">{item.internship.role}</p>
                        </div>
                        <Badge variant={isCritical ? "destructive" : "outline"} className={`whitespace-nowrap ${
                          isHigh ? 'border-orange-500 text-orange-700 dark:text-orange-400' :
                          isMedium ? 'border-yellow-500 text-yellow-700 dark:text-yellow-400' :
                          ''
                        }`}>
                          {item.daysUntil === 0 ? "Today" : item.daysUntil === 1 ? "Tomorrow" : `In ${item.daysUntil} days`}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="flex items-center gap-1.5 font-medium capitalize">
                          {item.deadlineType === "interview" ? <Calendar className="h-3.5 w-3.5" /> : <Clock className="h-3.5 w-3.5" />}
                          {item.deadlineType.replace('_', ' ')}
                        </span>
                        <span className="text-muted-foreground">{format(new Date(item.deadlineDate), 'MMM d')}</span>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Your most recently updated applications.</CardDescription>
          </CardHeader>
          <CardContent>
            {stats.recentActivity.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No applications yet. Start tracking!
              </div>
            ) : (
              <div className="space-y-6">
                {stats.recentActivity.map((internship) => (
                  <div key={internship.id} className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Link href={`/internships/${internship.id}`} className="font-medium hover:underline text-base leading-none">
                        {internship.company}
                      </Link>
                      <p className="text-sm text-muted-foreground">
                        {internship.role}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <InternshipStatusBadge status={internship.status} />
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(internship.updatedAt), 'MMM d, yyyy')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Pipeline Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(stats.byStatus).map(([status, count]) => (
                <div key={status} className="flex items-center justify-between">
                  <span className="text-sm font-medium capitalize">{status}</span>
                  <span className="text-sm text-muted-foreground font-mono bg-muted px-2 py-0.5 rounded">{count}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
