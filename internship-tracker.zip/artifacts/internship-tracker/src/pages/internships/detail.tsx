import { useState } from "react";
import { 
  useGetInternship, 
  getGetInternshipQueryKey, 
  useDeleteInternship,
  useListApplicationLogs,
  getListApplicationLogsQueryKey,
  useCreateApplicationLog,
  useDeleteApplicationLog
} from "@workspace/api-client-react";
import { Link, useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { InternshipStatusBadge } from "@/components/internship-status-badge";
import { format, differenceInDays } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  ArrowLeft, Building2, MapPin, Calendar, Link as LinkIcon, 
  DollarSign, User, Mail, Clock, Edit, Trash2, AlertCircle,
  Phone, Briefcase, FileText, CheckCircle, XCircle, MoreHorizontal, Send
} from "lucide-react";
import type { ApplicationLogInputLogType } from "@workspace/api-client-react/src/generated/api.schemas";

const LOG_TYPE_CONFIG = {
  note: { icon: FileText, label: "Note", color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-50 dark:bg-blue-500/10", border: "border-blue-200 dark:border-blue-500/20" },
  call: { icon: Phone, label: "Call", color: "text-orange-600 dark:text-orange-400", bg: "bg-orange-50 dark:bg-orange-500/10", border: "border-orange-200 dark:border-orange-500/20" },
  email: { icon: Mail, label: "Email", color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-50 dark:bg-purple-500/10", border: "border-purple-200 dark:border-purple-500/20" },
  interview: { icon: Briefcase, label: "Interview", color: "text-indigo-600 dark:text-indigo-400", bg: "bg-indigo-50 dark:bg-indigo-500/10", border: "border-indigo-200 dark:border-indigo-500/20" },
  offer: { icon: CheckCircle, label: "Offer", color: "text-green-600 dark:text-green-400", bg: "bg-green-50 dark:bg-green-500/10", border: "border-green-200 dark:border-green-500/20" },
  rejection: { icon: XCircle, label: "Rejection", color: "text-red-600 dark:text-red-400", bg: "bg-red-50 dark:bg-red-500/10", border: "border-red-200 dark:border-red-500/20" },
  other: { icon: MoreHorizontal, label: "Other", color: "text-muted-foreground", bg: "bg-muted", border: "border-border" }
};

function ActivityTimeline({ internshipId }: { internshipId: number }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { data: logs, isLoading } = useListApplicationLogs(internshipId, {
    query: {
      enabled: !!internshipId,
      queryKey: getListApplicationLogsQueryKey(internshipId)
    }
  });

  const createLog = useCreateApplicationLog();
  const deleteLog = useDeleteApplicationLog();

  const [content, setContent] = useState("");
  const [logType, setLogType] = useState<ApplicationLogInputLogType>("note");

  const handleCreateLog = () => {
    if (!content.trim()) return;
    createLog.mutate(
      { id: internshipId, data: { content, logType, loggedAt: new Date().toISOString() } },
      {
        onSuccess: () => {
          setContent("");
          setLogType("note");
          queryClient.invalidateQueries({ queryKey: getListApplicationLogsQueryKey(internshipId) });
          toast({ title: "Activity logged" });
        },
        onError: () => {
          toast({ title: "Failed to log activity", variant: "destructive" });
        }
      }
    );
  };

  const handleDeleteLog = (logId: number) => {
    deleteLog.mutate(
      { id: internshipId, logId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListApplicationLogsQueryKey(internshipId) });
        }
      }
    );
  };

  return (
    <Card className="mt-8 border-t-4 border-t-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Activity Timeline
        </CardTitle>
        <CardDescription>
          Keep track of communication, notes, and milestones
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Compose Area */}
        <div className="flex gap-4">
          <div className="mt-1">
            <div className={`h-10 w-10 rounded-full flex items-center justify-center border-2 border-primary/20 bg-primary/5 text-primary`}>
              <Edit className="h-4 w-4" />
            </div>
          </div>
          <div className="flex-1 border rounded-lg overflow-hidden bg-card focus-within:ring-1 focus-within:ring-ring transition-all">
            <Textarea 
              placeholder="Log a note, call, email, or milestone..." 
              className="border-0 focus-visible:ring-0 resize-none min-h-[80px] p-3 rounded-none shadow-none"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                  e.preventDefault();
                  handleCreateLog();
                }
              }}
            />
            <div className="bg-muted/30 p-2 flex items-center justify-between border-t border-border">
              <div className="w-[180px]">
                <Select value={logType} onValueChange={(val: any) => setLogType(val)}>
                  <SelectTrigger className="h-8 border-transparent bg-transparent hover:bg-muted focus:ring-0 shadow-none">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(LOG_TYPE_CONFIG).map(([key, config]) => {
                      const Icon = config.icon;
                      return (
                        <SelectItem key={key} value={key}>
                          <div className="flex items-center gap-2">
                            <Icon className={`h-4 w-4 ${config.color}`} />
                            <span>{config.label}</span>
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              <Button 
                size="sm" 
                onClick={handleCreateLog} 
                disabled={!content.trim() || createLog.isPending}
                className="h-8 gap-2"
              >
                <Send className="h-3.5 w-3.5" />
                Log Activity
              </Button>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-border before:via-border/50 before:to-transparent mt-8">
          {isLoading ? (
            <div className="space-y-4 pl-12 md:pl-0">
              {[1, 2].map((i) => (
                <div key={i} className="flex gap-4 md:justify-center">
                  <Skeleton className="h-24 w-full md:w-[45%]" />
                </div>
              ))}
            </div>
          ) : !logs || logs.length === 0 ? (
            <div className="text-center py-8 relative z-10 pl-12 md:pl-0">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-muted border-4 border-card mb-4 text-muted-foreground">
                <FileText className="h-5 w-5" />
              </div>
              <p className="text-muted-foreground text-sm">No activity logged yet.</p>
            </div>
          ) : (
            logs.map((log) => {
              const config = LOG_TYPE_CONFIG[log.logType as keyof typeof LOG_TYPE_CONFIG] || LOG_TYPE_CONFIG.other;
              const Icon = config.icon;
              
              return (
                <div key={log.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group pl-12 md:pl-0">
                  <div className={`absolute left-0 md:left-1/2 flex h-10 w-10 -translate-x-1/2 items-center justify-center rounded-full border-4 border-card ${config.bg} ${config.color} shadow-sm z-10`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  
                  <div className="w-full md:w-[calc(50%-2.5rem)]">
                    <Card className={`border hover:border-border transition-colors ${config.bg}`}>
                      <CardContent className="p-4 relative group">
                        <div className="flex justify-between items-start mb-2">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-full bg-background border ${config.border} ${config.color}`}>
                            {config.label}
                          </span>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(log.loggedAt || log.createdAt), 'MMM d, h:mm a')}
                            </span>
                            <button
                              onClick={() => handleDeleteLog(log.id)}
                              disabled={deleteLog.isPending}
                              className="text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                              title="Delete log"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                        <p className="text-sm text-foreground whitespace-pre-wrap">{log.content}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function InternshipDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const internshipId = id ? parseInt(id, 10) : 0;
  
  const { data: internship, isLoading } = useGetInternship(internshipId, {
    query: {
      enabled: !!internshipId,
      queryKey: getGetInternshipQueryKey(internshipId)
    }
  });

  const deleteInternship = useDeleteInternship();

  const handleDelete = () => {
    if (!confirm("Are you sure you want to delete this application?")) return;
    
    deleteInternship.mutate({ id: internshipId }, {
      onSuccess: () => {
        toast({ title: "Application deleted" });
        queryClient.invalidateQueries({ queryKey: ['/api/internships'] });
        queryClient.invalidateQueries({ queryKey: ['/api/internships/stats'] });
        setLocation("/internships");
      }
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-[200px]" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!internship) return <div className="text-center py-10">Application not found</div>;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <Link href="/internships">
          <Button variant="ghost" size="sm" className="gap-2 -ml-3 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
            Back to list
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Link href={`/internships/${internship.id}/edit`}>
            <Button variant="outline" size="sm" className="gap-2">
              <Edit className="h-4 w-4" />
              Edit
            </Button>
          </Link>
          <Button variant="destructive" size="sm" className="gap-2" onClick={handleDelete}>
            <Trash2 className="h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6 items-start md:items-end justify-between border-b pb-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-4xl font-serif font-bold tracking-tight">{internship.company}</h1>
            <InternshipStatusBadge status={internship.status} className="text-sm px-3 py-1" />
          </div>
          <p className="text-xl text-muted-foreground flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            {internship.role}
          </p>
        </div>
        
        {internship.applicationUrl && (
          <a href={internship.applicationUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-primary hover:underline">
            <LinkIcon className="h-4 w-4" />
            View Posting
          </a>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Details</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-6 sm:grid-cols-2">
            <div className="space-y-1">
              <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Calendar className="h-4 w-4" /> Date Applied
              </span>
              <p>{format(new Date(internship.appliedDate), 'MMMM d, yyyy')}</p>
            </div>

            {(internship.interviewDate || internship.offerDeadline) && (
              <div className="space-y-3 sm:col-span-2 py-4 border-y">
                <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" /> Important Deadlines
                </h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  {internship.interviewDate && (
                    <div className="space-y-1">
                      <span className="text-xs font-medium text-muted-foreground">Interview Date</span>
                      <p className="flex items-center gap-2">
                        {format(new Date(internship.interviewDate), 'MMMM d, yyyy')}
                        {differenceInDays(new Date(internship.interviewDate), new Date()) <= 7 && differenceInDays(new Date(internship.interviewDate), new Date()) >= 0 && (
                          <span className="flex h-2 w-2 rounded-full bg-destructive animate-pulse" title="Upcoming within 7 days" />
                        )}
                      </p>
                    </div>
                  )}
                  {internship.offerDeadline && (
                    <div className="space-y-1">
                      <span className="text-xs font-medium text-muted-foreground">Offer Deadline</span>
                      <p className="flex items-center gap-2">
                        {format(new Date(internship.offerDeadline), 'MMMM d, yyyy')}
                        {differenceInDays(new Date(internship.offerDeadline), new Date()) <= 7 && differenceInDays(new Date(internship.offerDeadline), new Date()) >= 0 && (
                          <span className="flex h-2 w-2 rounded-full bg-destructive animate-pulse" title="Upcoming within 7 days" />
                        )}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="space-y-1">
              <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <MapPin className="h-4 w-4" /> Location
              </span>
              <p>
                {internship.remote ? (
                  <span className="bg-secondary px-2 py-0.5 rounded text-sm">Remote</span>
                ) : null}
                {internship.remote && internship.location && " • "}
                {internship.location || (!internship.remote && "Not specified")}
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <DollarSign className="h-4 w-4" /> Compensation
              </span>
              <p>{internship.payRate || "Not specified"}</p>
            </div>

            <div className="space-y-1">
              <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Clock className="h-4 w-4" /> Duration
              </span>
              <p>
                {internship.startDate ? format(new Date(internship.startDate), 'MMM yyyy') : "?"} 
                {" - "} 
                {internship.endDate ? format(new Date(internship.endDate), 'MMM yyyy') : "?"}
              </p>
            </div>
            
            {internship.notes && (
              <div className="space-y-2 sm:col-span-2 mt-4 pt-4 border-t">
                <span className="text-sm font-medium text-muted-foreground">Notes</span>
                <div className="prose prose-sm dark:prose-invert max-w-none p-4 bg-muted/50 rounded-lg">
                  {internship.notes.split('\n').map((line, i) => (
                    <p key={i} className="mb-2 last:mb-0">{line}</p>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Contact Info</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-1">
              <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <User className="h-4 w-4" /> Name
              </span>
              <p>{internship.contactName || "—"}</p>
            </div>
            <div className="space-y-1">
              <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Mail className="h-4 w-4" /> Email
              </span>
              {internship.contactEmail ? (
                <a href={`mailto:${internship.contactEmail}`} className="text-primary hover:underline">
                  {internship.contactEmail}
                </a>
              ) : (
                <p>—</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <ActivityTimeline internshipId={internship.id} />
    </div>
  );
}
