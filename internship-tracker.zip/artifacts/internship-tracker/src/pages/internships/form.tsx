import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Link, useLocation, useParams } from "wouter";
import { 
  useCreateInternship, 
  useUpdateInternship, 
  useGetInternship, 
  getGetInternshipQueryKey 
} from "@workspace/api-client-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Save } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";

const formSchema = z.object({
  company: z.string().min(1, "Company name is required"),
  role: z.string().min(1, "Role is required"),
  status: z.enum(["applied", "interviewing", "offered", "accepted", "rejected", "withdrawn"]),
  appliedDate: z.string().min(1, "Date is required"),
  interviewDate: z.string().optional().nullable().or(z.literal("")),
  offerDeadline: z.string().optional().nullable().or(z.literal("")),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  location: z.string().optional().nullable(),
  remote: z.boolean().default(false),
  payRate: z.string().optional().nullable(),
  applicationUrl: z.string().url("Must be a valid URL").optional().nullable().or(z.literal("")),
  contactName: z.string().optional().nullable(),
  contactEmail: z.string().email("Must be a valid email").optional().nullable().or(z.literal("")),
  notes: z.string().optional().nullable(),
});

type FormValues = z.infer<typeof formSchema>;

export default function InternshipForm() {
  const { id } = useParams();
  const isEditing = !!id && id !== "new";
  const internshipId = isEditing ? parseInt(id!, 10) : 0;
  
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: internship, isLoading } = useGetInternship(internshipId, {
    query: {
      enabled: isEditing,
      queryKey: getGetInternshipQueryKey(internshipId)
    }
  });

  const createMutation = useCreateInternship();
  const updateMutation = useUpdateInternship();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      company: "",
      role: "",
      status: "applied",
      appliedDate: new Date().toISOString().split('T')[0],
      remote: false,
    }
  });

  useEffect(() => {
    if (internship && isEditing) {
      form.reset({
        company: internship.company,
        role: internship.role,
        status: internship.status as any,
        appliedDate: internship.appliedDate,
        interviewDate: internship.interviewDate || "",
        offerDeadline: internship.offerDeadline || "",
        startDate: internship.startDate || "",
        endDate: internship.endDate || "",
        location: internship.location || "",
        remote: internship.remote,
        payRate: internship.payRate || "",
        applicationUrl: internship.applicationUrl || "",
        contactName: internship.contactName || "",
        contactEmail: internship.contactEmail || "",
        notes: internship.notes || "",
      });
    }
  }, [internship, isEditing, form]);

  const onSubmit = (data: FormValues) => {
    // Clean up empty strings to nulls for optional fields
    const cleanedData = {
      ...data,
      interviewDate: data.interviewDate || null,
      offerDeadline: data.offerDeadline || null,
      startDate: data.startDate || null,
      endDate: data.endDate || null,
      location: data.location || null,
      payRate: data.payRate || null,
      applicationUrl: data.applicationUrl || null,
      contactName: data.contactName || null,
      contactEmail: data.contactEmail || null,
      notes: data.notes || null,
    };

    if (isEditing) {
      updateMutation.mutate({ id: internshipId, data: cleanedData }, {
        onSuccess: () => {
          toast({ title: "Application updated" });
          queryClient.invalidateQueries({ queryKey: getGetInternshipQueryKey(internshipId) });
          queryClient.invalidateQueries({ queryKey: ['/api/internships'] });
          queryClient.invalidateQueries({ queryKey: ['/api/internships/stats'] });
          setLocation(`/internships/${internshipId}`);
        }
      });
    } else {
      createMutation.mutate({ data: cleanedData }, {
        onSuccess: (newInternship) => {
          toast({ title: "Application added successfully!" });
          queryClient.invalidateQueries({ queryKey: ['/api/internships'] });
          queryClient.invalidateQueries({ queryKey: ['/api/internships/stats'] });
          setLocation(`/internships/${newInternship.id}`);
        }
      });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  if (isEditing && isLoading) {
    return <div className="p-8 text-center">Loading...</div>;
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in duration-300 pb-24">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => window.history.back()}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-serif font-bold tracking-tight">
          {isEditing ? "Edit Application" : "New Application"}
        </h1>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          
          <div className="bg-card border rounded-xl p-6 space-y-6">
            <h2 className="text-xl font-semibold mb-4 border-b pb-2">The Basics</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="company"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Acme Corp" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Software Engineering Intern" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="applied">Applied</SelectItem>
                        <SelectItem value="interviewing">Interviewing</SelectItem>
                        <SelectItem value="offered">Offered</SelectItem>
                        <SelectItem value="accepted">Accepted</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                        <SelectItem value="withdrawn">Withdrawn</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="appliedDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date Applied</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="applicationUrl"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>Link to Posting</FormLabel>
                    <FormControl>
                      <Input placeholder="https://..." {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          <div className="bg-card border rounded-xl p-6 space-y-6">
            <h2 className="text-xl font-semibold mb-4 border-b pb-2">Logistics</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. San Francisco, CA" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="remote"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 pt-8 h-[72px]">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Remote Position</FormLabel>
                    </div>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="interviewDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Interview Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="offerDeadline"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Offer Deadline</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date (approx)</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date (approx)</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="payRate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Compensation</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. $45/hr" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          <div className="bg-card border rounded-xl p-6 space-y-6">
            <h2 className="text-xl font-semibold mb-4 border-b pb-2">Notes & Contacts</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="contactName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Recruiter/Contact Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Jane Doe" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="contactEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="jane@acme.com" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Interview prep, thoughts, follow-up dates..." 
                        className="min-h-[150px]"
                        {...field} 
                        value={field.value || ""} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          <div className="flex justify-end gap-4 sticky bottom-4 p-4 bg-background/80 backdrop-blur-sm border rounded-xl shadow-lg">
            <Button type="button" variant="outline" onClick={() => window.history.back()}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="gap-2">
              <Save className="h-4 w-4" />
              {isPending ? "Saving..." : "Save Application"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
