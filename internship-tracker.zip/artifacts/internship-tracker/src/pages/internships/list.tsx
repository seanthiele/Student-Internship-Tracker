import { useListInternships, getListInternshipsQueryKey, useDeleteInternship } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { InternshipStatusBadge } from "@/components/internship-status-badge";
import { format } from "date-fns";
import { Building, MapPin, Search, Calendar, ChevronRight, Trash2, BriefcaseBusiness } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function InternshipsList() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const params = {
    ...(search ? { search } : {}),
    ...(statusFilter !== "all" ? { status: statusFilter } : {})
  };

  const { data: internships, isLoading } = useListInternships(params, {
    query: {
      queryKey: getListInternshipsQueryKey(params)
    }
  });

  const deleteInternship = useDeleteInternship();

  const handleDelete = (id: number, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm("Are you sure you want to delete this application?")) return;
    
    deleteInternship.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Application deleted" });
        queryClient.invalidateQueries({ queryKey: getListInternshipsQueryKey() });
        queryClient.invalidateQueries({ queryKey: ['/api/internships/stats'] });
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h1 className="text-3xl font-serif font-bold tracking-tight">Applications</h1>
          <p className="text-muted-foreground mt-1">Track and manage your internship pipeline.</p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search companies or roles..." 
              className="pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="applied">Applied</SelectItem>
              <SelectItem value="interviewing">Interviewing</SelectItem>
              <SelectItem value="offered">Offered</SelectItem>
              <SelectItem value="accepted">Accepted</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="withdrawn">Withdrawn</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-3">
        {isLoading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full rounded-xl" />
          ))
        ) : internships?.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-xl border border-dashed">
            <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <BriefcaseBusiness className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-1">No applications found</h3>
            <p className="text-muted-foreground mb-4">
              {search || statusFilter !== "all" 
                ? "Try adjusting your search or filters."
                : "You haven't added any applications yet."}
            </p>
            {!(search || statusFilter !== "all") && (
              <Link href="/internships/new">
                <Button>Add Your First Application</Button>
              </Link>
            )}
          </div>
        ) : (
          internships?.map((internship, i) => (
            <Link key={internship.id} href={`/internships/${internship.id}`}>
              <Card className="hover-elevate cursor-pointer transition-colors hover:border-primary/50 overflow-hidden group">
                <CardContent className="p-5 flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold truncate group-hover:text-primary transition-colors">
                        {internship.company}
                      </h3>
                      <InternshipStatusBadge status={internship.status} />
                    </div>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1.5">
                        <Building className="h-4 w-4" />
                        <span className="truncate max-w-[200px]">{internship.role}</span>
                      </div>
                      {(internship.location || internship.remote) && (
                        <div className="flex items-center gap-1.5">
                          <MapPin className="h-4 w-4" />
                          <span>{internship.remote ? 'Remote' : internship.location}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-1.5">
                        <Calendar className="h-4 w-4" />
                        <span>Applied {format(new Date(internship.appliedDate), 'MMM d')}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={(e) => handleDelete(internship.id, e)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}

